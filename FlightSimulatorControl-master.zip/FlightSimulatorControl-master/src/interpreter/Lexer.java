package interpreter;
import java.util.ArrayList;

public interface Lexer<V> {
	public ArrayList<String[]> lexicalCheck();
}
