package interpreter;

public interface Parser {
    public void parse();
}
