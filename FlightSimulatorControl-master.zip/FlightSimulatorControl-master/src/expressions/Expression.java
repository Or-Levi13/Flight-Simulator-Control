package expressions;

public interface Expression {
	public double calculate();
}
