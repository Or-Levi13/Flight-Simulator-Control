package commands;

public interface Command {
	void executeCommand(String[] array);
}
